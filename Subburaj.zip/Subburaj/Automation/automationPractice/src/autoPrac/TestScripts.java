package autoPrac;

import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TestScripts extends Util {

	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Util.broserSetUp("chrome");
		Util.getUrl("http://automationpractice.com/index.php");
		Thread.sleep(1000);
		ObjRepos.signIn.click();
		Thread.sleep(1000);
		
		//Create Account
		
		ObjRepos.emailAddress.sendKeys("es.subburaj@gmail.com");
		ObjRepos.submitCreate.click();
		Thread.sleep(1000);
		ObjRepos.title.click();
		ObjRepos.firstName.sendKeys("Subburaj");
		ObjRepos.lastName.sendKeys("S");
		ObjRepos.password.sendKeys("password");
		Util.selectOption(ObjRepos.selectDay, "15");
		Util.selectOption(ObjRepos.selectMonth, "9");
		Util.selectOption(ObjRepos.selectYear, "1989");
		//ObjRepos.addressFirstName.sendKeys("Subburaj");
		//ObjRepos.addressLastName.sendKeys("S");
		ObjRepos.address.sendKeys("street name");
		ObjRepos.addressCity.sendKeys("New York");
		ObjRepos.addressPostCode.sendKeys("99999");
		Util.selectOption(ObjRepos.addressSelectState, "5");
		Util.selectOption(ObjRepos.addressSelectCountry, "21");
		ObjRepos.addressMobileNumber.sendKeys("99999999");
		ObjRepos.addressAlias.sendKeys("sssss");
		ObjRepos.registerButton.click();
		
		//Validating my name top right corner
		String name = ObjRepos.myName.getText();
		if(name.equalsIgnoreCase("Subbura S"))
		System.out.println("My name is displayed in the top right corner");
		else
		System.out.println("VALIDATION Failed");

		//Validating MY WISHLISTS link
		boolean result;
		result=driver.findElement(By.partialLinkText("mywishlist")).isDisplayed();
		if(result == true)
		System.out.println("My Wishlist button is present");
		else
		System.out.println("Validation Failed");
		
		ObjRepos.myWishList.click();
		
		//Validating TOP SELLERS list on the left side
		
		String val = driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/H4/a")).getText();
		if(val.equalsIgnoreCase("TOP SELLERS"))
			System.out.println("VALIDATION PASSED");
		else
			System.out.println("VALIDATION FAILED");
		
		//Adding to wishlist
		driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/div//li[1]/div/p")).click();
		driver.findElement(By.xpath("//*[@id='wishlist_button']")).click();
		
		String val1= driver.findElement(By.xpath("//*[@id='product']/div[2]//div/p")).getText();
		if(val1.equalsIgnoreCase("Added to wishlist"))
			System.out.println("VALIDAATION PASSED");
		else
			System.out.println("VALIDATION FAILED");
		//Navigating to My wishlist
		ObjRepos.myName.click();
		ObjRepos.myWishList.click();
		List<WebElement> productList = driver.findElements(By.xpath("//*[@id='wishlist_7651']/td[1]"));
		if(productList.size()>0)
			System.out.println("Product added under my wishlist");
		else
			System.out.println("No products available in wishlist");
	
		//Closing Window
		Util.browserClose();
		
	}

}
