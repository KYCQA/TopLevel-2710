package autoPrac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Util {
	public static WebDriver driver;
	public static void broserSetUp(String browser)
	{
		if (browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
		}
	}
	public static void getUrl(String url)
	{
		driver.get(url);
	}
	
	public static void selectOption(WebElement wb, String name)
	{
		Select st = new Select(wb);
		st.selectByValue(name);
	}
	
	public static void browserClose()
	{
		driver.quit();
	}
}
