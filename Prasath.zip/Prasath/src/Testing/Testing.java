package Testing;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Testing {
	
	public static WebDriver driver;
	
	public static String browserurl = "http://automationpractice.com/index.php";
	
	public static String temp;
	
	public static void Launch_browser(){
		
		System. setProperty("webdriver.chrome.driver", "C://Users//Administrator//Downloads//chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(browserurl);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
	}
	
	
	public static void Click_Sign_in(){
		
		WebElement signin_btn ;
		
		try {
		signin_btn = driver.findElement(By.xpath("//a[@class='login']"));
		signin_btn.click();
		System.out.println("Sign In link is Clicked");
		
		}
		catch (Exception e){
			System.out.println("SIGN In link does not exist");
			}
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
				
	}
	
	public static void Create_Account(){
		
		WebElement Emailid , Create_Account_btn ;
		try {
		Emailid = driver.findElement(By.xpath("//input[@id='email_create']"));	
		Emailid.sendKeys("pprasanth6@gmail.com");	
		Create_Account_btn = driver.findElement(By.xpath("//button[@type='submit'][@id='SubmitCreate']"));
		Create_Account_btn.click();
		}
		
		catch (Exception e){
			System.out.println("Create Account button or Emaild id doesnt Exist");
			}
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		
	}
	
	
	public static void registration(){
		
		WebElement rd_btn,fname,lname,pwd,oday,omonth,oyear,ofname,olname,ocompany,oaddress1,oaddress2,ocity,opostcode,ostate,ocountry,ophone,orefaddress,osubmit ;
		try {
		rd_btn = driver.findElement(By.xpath("(//div[@class='radio-inline'])[1]"));
		rd_btn.click();
		Thread.sleep(1000);
		fname = driver.findElement(By.xpath("//input[@id='customer_firstname']"));
		fname.sendKeys("Prasanth");
		Thread.sleep(1000);
		lname=driver.findElement(By.xpath("//input[@id='customer_lastname']"));
		lname.sendKeys("Prabhakaran");
		Thread.sleep(1000);
		pwd=driver.findElement(By.xpath("//input[@id='passwd']"));
		pwd.sendKeys("Acc1234$$");
		Thread.sleep(1000);
		/*oday = driver.findElement(By.xpath("//select[@id='days']"));
		omonth = driver.findElement(By.xpath("//select[@id='months']"));
		oyear= driver.findElement(By.xpath("//select[@id='years"));
		
		Select odselect = new Select(oday);
		List<WebElement> odlist = odselect.getOptions();
		odlist.get(3);
		Thread.sleep(1000);
		Select omselect = new Select(omonth);
		List<WebElement> omlist = omselect.getOptions();
		omlist.get(3);
		Thread.sleep(1000);
		Select oyselect = new Select(oyear);
		List<WebElement> oylist = omselect.getOptions();
		oylist.get(3);*/
		Thread.sleep(1000);
		ofname= driver.findElement(By.xpath("//input[@id='firstname']"));
		ofname.sendKeys("arg");
		Thread.sleep(1000);
		olname = driver.findElement(By.xpath("//input[@id='lastname']"));
		olname.sendKeys("arg");
		Thread.sleep(1000);
		ocompany=driver.findElement(By.xpath("//input[@id='company']"));
		ocompany.sendKeys("Company");
		Thread.sleep(1000);
		oaddress1=driver.findElement(By.xpath("//input[@id='address1']"));
		oaddress1.sendKeys("Address");
		Thread.sleep(1000);
		oaddress2 = driver.findElement(By.xpath("//input[@id='address2']"));
		oaddress2.sendKeys("Address");
		Thread.sleep(1000);
		ocity = driver.findElement(By.xpath("//input[@id='city']"));
		ocity.sendKeys("Chennai");
		Thread.sleep(1000);
		opostcode = driver.findElement(By.xpath("//input[@id='postcode']"));
		opostcode.sendKeys("00006");
		Thread.sleep(1000);
		ostate = driver.findElement(By.xpath("//select[@id='id_state']"));
		Select osstate = new Select(ostate);
		osstate.selectByVisibleText("Arizona");
		Thread.sleep(1000);
		ocountry = driver.findElement(By.xpath("//select[@id='id_country']"));
		Select oCuntry = new Select(ocountry);
		oCuntry.selectByVisibleText("United States");
		Thread.sleep(1000);
		ophone = driver.findElement(By.xpath("//input[@id='phone_mobile']"));
		ophone.sendKeys("12345690");
		Thread.sleep(1000);
		orefaddress = driver.findElement(By.xpath("//input[@id='alias']"));
		orefaddress.sendKeys("abcd");
		Thread.sleep(1000);
		osubmit = driver.findElement(By.xpath("//button[@id='submitAccount']"));
		osubmit.click();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		}
		catch (Exception e){
			System.out.println("Element Identification Error");
			}

	}
	
	public static void My_Accounts(){
		WebElement ousername,owishlist,oTopseller;
		ousername = driver.findElement(By.xpath("//a[@class='account']"));
		System.out.println("Logged In Username is " + ousername.getText());
		String uname = ousername.getText();
		if (uname.equals("Prasanth Prabhakaran")){
			System.out.println("User is Logged in Successfully");
		}
		owishlist = driver.findElement(By.xpath("//a[@title='My wishlists']"));
		
		if (owishlist.isDisplayed()){
			System.out.println("Wishlist link is Displayed");
			owishlist.click();
			oTopseller = driver.findElement(By.xpath("//a[@title='View a top sellers products']"));
			if (oTopseller.isDisplayed()){
							System.out.println("Topseller link is Displayed");
			}
		}
			
	}
	
	public static void Add_Items() throws Exception{
		
		WebElement itemname,oitem,owishlist,omsg,ousername,wishlistlnk,olist,olink,oitemname;
		oitem = driver.findElement(By.xpath("(//div[@id='best-sellers_block_right']//li//a)[1]"));
		oitem.click();
		itemname = driver.findElement(By.xpath("(//div[@id='best-sellers_block_right']//li//div)[1]//a"));
		System.out.println("Item Name is " + itemname.getText());
		temp = itemname.getText();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		
		owishlist= driver.findElement(By.xpath("//a[@id='wishlist_button']"));
		if (owishlist.isDisplayed()){
			System.out.println("Add to Wishlist Displayed");
			owishlist.click();
			omsg = driver.findElement(By.xpath("//a[@title='Close']"));
			omsg.click();
			Thread.sleep(5000);
			ousername = driver.findElement(By.xpath("//a[@title='View my customer account']"));
			ousername.click();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			wishlistlnk = driver.findElement(By.xpath("//a[@title='My wishlists']"));
			wishlistlnk.click();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			olist = driver.findElement(By.xpath("//table"));
			
			if(olist.isDisplayed()){
				System.out.println("Item added to List Successfully");
			}
			
			else{
				
				System.out.println("Item not added to the List");
			}
			
			olink = driver.findElement(By.xpath("//a[contains(text(),'My wishlist')]"));
			olink.click();
			oitemname = driver.findElement(By.xpath("(//*[@class='product-name'])[11]"));
			String temp2 = oitemname.getText();
			
			if (temp == temp2.trim())
			System.out.println("Same Item Added");
			
			}
		
		else {
			
			System.out.println("Different Item Added");
		}
		
		
	}
	
	
	public static void main (String [] args) throws Exception{
		Launch_browser();
		Click_Sign_in();
		Create_Account();
		registration();
		My_Accounts();
		Add_Items();
		
	}
	

}
