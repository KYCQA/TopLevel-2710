package commonMethods;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import package1.SeMethods;

public class ProjectMethods implements SeMethods{

	
	public  void login() throws InterruptedException{
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Desktop\\MyRegistration\\src\\commonMethods\\drivers\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(3000);
		String URL="automationpractice.com/";
		driver.get(URL);
		WebElement ele=driver.findElement(By.linkText("Sign in"));		
				
		ele.click();
		
		System.out.println("Sign in icon clicked");
		
		WebElement email=driver.findElement(By.id("email_create"));
		
		email.sendKeys("hellotest123@gmail.com");
		
		WebElement submit=driver.findElement(By.name("SubmitCreate"));
		submit.click();
		
		WebElement fname=driver.findElement(By.id("customer_firstname"));
		
		fname.sendKeys("Hello");
		
		WebElement lname=driver.findElement(By.id("customer_lastname"));
		
		lname.sendKeys("Hello");
		
		WebElement email1=driver.findElement(By.id("email"));
		
		email1.sendKeys("hello123@gmail.com");
		
		WebElement pwd=driver.findElement(By.id("passwd"));
		
		pwd.sendKeys("Password");
		
		WebElement daysdropdwn=driver.findElement(By.id("days"));
		
		Select days=new Select(daysdropdwn);
		days.selectByValue("May");
		
		WebElement monthdropdwn=driver.findElement(By.id("months"));
		
		Select month=new Select(monthdropdwn);
		month.selectByValue("May");
		
		
	
		
		
		
		
		
		
		
				
			
	}

	@Override
	public void Registration() {
		// TODO Auto-generated method stub
		
	}

	
	}
	


