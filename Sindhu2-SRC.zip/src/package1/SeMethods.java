package package1;

public interface SeMethods {
	
	
	public void login() throws InterruptedException;
	
	
	
	public void Registration();
	
	
	

}
