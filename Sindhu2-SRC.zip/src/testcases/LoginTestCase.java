package testcases;

import commonMethods.ProjectMethods;

public class LoginTestCase extends ProjectMethods{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		LoginTestCase ele1=new LoginTestCase();
		ele1.login();
		
		
		
	}

}
