package createAccount;
//package createAccount;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class CreateTest {

	public static void main(String[] args) throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\workspace\\AutomationPractice\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		driver.findElement(By.xpath("//a[@class='login']")).click();
		// Register
		driver.findElement(By.id("email_create")).sendKeys("paa2testing@gmail.com");
		driver.findElement(By.id("SubmitCreate")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//input[@name='id_gender'])[2]")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("MyNewPaaTest");
		driver.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("EQ");
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("Pass1word");
		driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys("MyNewPaaTest");
		driver.findElement(By.xpath("//input[@id='lastname']")).sendKeys("EQ");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys("TBM");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("Chennai");
		WebElement element = driver.findElement(By.xpath("(//select[@id='id_state'])"));
		Select element1 = new Select(element);
		element1.selectByValue("2");
		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys("60006");
		//WebElement country = driver.findElement(By.xpath("//select[@id='id_country']"));
		//Select element2 = new Select(country);
		//element2.selectByValue("2");
		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("8739281039");
		driver.findElement(By.xpath("//button[@id='submitAccount']")).click();
		WebElement nameElement = driver.findElement(By.cssSelector("a[class='account']"));
		// Verify User name
		if (nameElement.getText() == "MyTest EQ") {
		  System.out.print("User Name is displayed correctly");
		}
		// Verify Wish list
		WebElement wishElement = driver.findElement(By.cssSelector("a[title='My wishlists']"));
		if (wishElement.isDisplayed()) {
			System.out.println("My Wishlist list is displayed");
		}
		wishElement.click();
		// Verify Top Sellers section
		WebElement sellerElement = driver.findElement(By.cssSelector("a[title='View a top sellers products']"));
		if (sellerElement.isDisplayed()) {
			System.out.println("Top Sellers section is displayed");
		}
		driver.findElement(By.cssSelector("li[class='clearfix']:first-child a")).click();
		driver.findElement(By.cssSelector("a[id='wishlist_button']")).click();
		WebElement popElement = driver.findElement(By.cssSelector("p[class='fancybox-error']"));
		// Verify wishlist confirmation
		if (popElement.getText() == "Added to your wishlist") {
			  System.out.print("Confirmation is displayed properly");
		}
		driver.findElement(By.cssSelector("a[title='Close']")).click();
		}
	}


