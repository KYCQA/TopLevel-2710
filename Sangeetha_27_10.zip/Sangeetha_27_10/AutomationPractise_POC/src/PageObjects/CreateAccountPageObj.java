package PageObjects;

import org.openqa.selenium.By;

public class CreateAccountPageObj {

	public static final By signin = By.xpath("//*[contains(text(),'signin')");
	public static final By username = By.xpath("//input[contains(text(),'username')");
	public static final By password = By.xpath("//input[contains(text(),'password')");
	public static final By login = By.xpath("//*[contains(text(),'login')");
	
}
