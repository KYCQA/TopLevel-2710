package PageObjects;

public class MyAccountPageObj {

}
