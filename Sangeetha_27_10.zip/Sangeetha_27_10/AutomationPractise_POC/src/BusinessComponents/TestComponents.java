package BusinessComponents;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.CreateAccountPageObj;

public class TestComponents {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver");		
		WebDriver driver = new ChromeDriver();
		Properties prop = new Properties();
		String url = prop.getProperty("ApplicationUrl");
		driver.get("url");
		driver.findElement(CreateAccountPageObj.signin).click();
		driver.findElement(CreateAccountPageObj.username).sendKeys("");
		driver.findElement(CreateAccountPageObj.password).sendKeys("");
		driver.findElement(CreateAccountPageObj.login).click();
		
	

	}

}
