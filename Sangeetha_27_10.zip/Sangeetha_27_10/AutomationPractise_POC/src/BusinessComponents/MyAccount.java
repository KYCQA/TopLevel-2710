package BusinessComponents;

public class MyAccount {

}
