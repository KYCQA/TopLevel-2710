import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class CustomerRegister {

	 static ExtentReports extent ;
	 static ExtentTest logger ;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 System.out.println(System.getProperty("user.dir"));
		 extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/Customer_Register.html", true);
		
	
		try
		{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver;
		
		String datalist[][]={ {"1", "Firstone","Lastone","Pass123","10.08.1990","Address01","chennai01","12345","9123456789","Testy11@gmail.com"}, {"2", "Firsttwo","Lasttwo","Pass123","10.06.1990","Address02","chennai02","12345","9144456789","Testy12@gmail.com"}}; 

		//String datalist[][]={ {"1", "Firstone","Lastone","Pass123","10.08.1990","Address01","chennai01","12345","9123456789","Testd0088t@gmail.com"}}; 

		for(int i=0;i<datalist.length;i++)
		{
					driver = new ChromeDriver();
					driver.get("http://automationpractice.com/index.php?id_category=5&controller=category");
					driver.manage().window().maximize();
				
			    logger=extent.startTest("Cutomer_Register_"+datalist[i][1]+"\tTC_"+i);
					
				System.out.println("Title\t"+datalist[i][0]);
				System.out.println("FirstName\t"+datalist[i][1]);
				System.out.println("LastName\t"+datalist[i][2]);
				System.out.println("Password\t"+datalist[i][3]);
				System.out.println("DOB\t"+datalist[i][4]);
				System.out.println("Address\t"+datalist[i][5]);
				System.out.println("city\t"+datalist[i][6]);
				System.out.println("Zip\t"+datalist[i][7]);
				System.out.println("Mobile\t"+datalist[i][8]);
				System.out.println("Mail\t"+datalist[i][9]);
				
				SeleniumAction.Click(driver, "//*[@id='header']/div[2]/div/div/nav/div[1]/a",logger);
				
				SeleniumAction.SetText(driver, "//*[@id='email_create']",datalist[i][9],logger);
				
				SeleniumAction.TimeOut(3000);
				
				SeleniumAction.Click(driver, "//*[@id='SubmitCreate']/span",logger);
				
				SeleniumAction.TimeOut(3000);
				
				if(datalist[i][0].equalsIgnoreCase("1"))
				{
					SeleniumAction.Click(driver, "//*[@id='id_gender1']",logger);	
				}else
				{
					SeleniumAction.Click(driver, "//*[@id='id_gender2']",logger);
				}
							
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver, "//*[@id='customer_firstname']",datalist[i][1],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver, "//*[@id='customer_lastname']",datalist[i][2],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver, "//*[@id='passwd']",datalist[i][3],logger);
				SeleniumAction.TimeOut(3000);
				
				SeleniumAction.SelectDropdown(driver, "days","1");
				SeleniumAction.SelectDropdown(driver, "months","1");
				SeleniumAction.SelectDropdown(driver, "years","1989");
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver,"//*[@id='address1']",datalist[i][2],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver,"//*[@id='city']",datalist[i][6],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SelectDropdown(driver, "id_state","1");
								
				SeleniumAction.SetText(driver,"//*[@id='postcode']",datalist[i][7],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.SetText(driver,"//*[@id='phone_mobile']",datalist[i][8],logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.Click(driver, "//*[@id='submitAccount']/span",logger);
				
				
				boolean status_My_WISHLIST=SeleniumAction.Verify(driver, "//*[@id='header']/div[2]/div/div/nav/div[1]/a/span",datalist[i][1]+" "+datalist[i][2],"My WISHLIST");
				String screenShotPath1 = SeleniumAction.getScreenhot(driver,"status_My_WISHLIST");
				if(status_My_WISHLIST)
				{
				 logger.log(LogStatus.PASS, "My WISHLIST Status is pass"+ logger.addScreenCapture(screenShotPath1));
				}else
				{
				logger.log(LogStatus.FAIL, "My WISHLIST Status is fail"+ logger.addScreenCapture(screenShotPath1));	
				}
				 
				SeleniumAction.TimeOut(3000);
				SeleniumAction.Click(driver, "//*[@id='center_column']/div/div[2]/ul/li/a/span",logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.Click(driver, "//*[@id='best-sellers_block_right']/div/ul/li[1]/a/img",logger);
				SeleniumAction.TimeOut(3000);
				SeleniumAction.Click(driver, "//*[@id='add_to_cart']/button/span",logger);
				SeleniumAction.TimeOut(3000);
				boolean status_Product_ADD=SeleniumAction.VerifyContain(driver, "//*[@id='layer_cart']/div[1]/div[1]/h2","successfully added","Product ADD Cart");
				String screenShotPath = SeleniumAction.getScreenhot(driver,"status_Product_ADD");
				if(status_Product_ADD)
				{
				 logger.log(LogStatus.PASS, "status_Product_ADD Status is pass" + logger.addScreenCapture(screenShotPath));
				}else
				{
				logger.log(LogStatus.FAIL, "status_Product_ADD Status is FAIL" + logger.addScreenCapture(screenShotPath));
				} 
				
				
				
			    extent.endTest(logger);
				driver.close();
		}
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		
		 extent.flush();
		 extent.close();

	}

}
