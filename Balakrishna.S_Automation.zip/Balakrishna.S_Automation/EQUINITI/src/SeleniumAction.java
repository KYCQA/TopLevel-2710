import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;




public class SeleniumAction {

	
	
	public static boolean Click(WebDriver driver,String xpath,ExtentTest logger)
	{
		
		boolean flag=false;
		try{
			
			driver.findElement(By.xpath(xpath)).click();
			logger.log(LogStatus.PASS,"Click Action PASS");
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
			logger.log(LogStatus.FAIL,"Click Action FAIL");
		}
		return flag;
	}
	
	public static boolean SetText(WebDriver driver,String xpath,String inputstr,ExtentTest logger)
	{
		
		boolean flag=false;
		try{
			
			driver.findElement(By.xpath(xpath)).sendKeys(inputstr);
			logger.log(LogStatus.PASS, "SetText is pass\t"+inputstr);
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
			logger.log(LogStatus.FAIL, "SetText is fail\t"+inputstr);
		}
		return flag;
	}
	
	public static boolean TimeOut(int timeout)
	{
		
		boolean flag=false;
		try{
			Thread.sleep(timeout);
			
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
		}
		return flag;
	}
	
	public static boolean SelectDropdown(WebDriver driver,String xpath,String inputstr)
	{
		
		boolean flag=false;
		try{
			

			WebElement element = driver.findElement(By.id(xpath));
			Select oSelect = new Select(element);
			oSelect.selectByValue(inputstr);
			
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
		}
		return flag;
	}
	
	public static boolean Verify(WebDriver driver,String xpath,String inputstr,String Label)
	{
		
		boolean flag=false;
		try{
			

			String element = driver.findElement(By.xpath(xpath)).getText();
			if(element.trim().equalsIgnoreCase(inputstr))
			{
				System.out.println(Label+"\t"+"PASS");
			}else
			{
				System.out.println(Label+"\t"+"FAIL");
			}
			
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
		}
		return flag;
	}
	
	public static boolean VerifyContain(WebDriver driver,String xpath,String inputstr,String Label)
	{
		
		boolean flag=false;
		try{
			

			String element = driver.findElement(By.xpath(xpath)).getText();
			if(element.trim().contains(inputstr))
			{
				System.out.println(Label+"\t"+"PASS");
				
			}else
			{
				System.out.println(Label+"\t"+"FAIL");
			}
			
			flag=true;
		}catch(Exception ex)
		{
			flag=false;
		}
		return flag;
	}
	
	    public static String getScreenhot(WebDriver driver, String screenshotName) throws Exception {
		 String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		 TakesScreenshot ts = (TakesScreenshot) driver;
		 File source = ts.getScreenshotAs(OutputType.FILE);
		                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
		 String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/"+screenshotName+dateName+".png";
		 File finalDestination = new File(destination);
		 FileUtils.copyFile(source, finalDestination);
		 return destination;
		 }
}
