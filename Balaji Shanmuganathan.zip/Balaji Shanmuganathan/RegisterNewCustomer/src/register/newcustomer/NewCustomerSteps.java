package register.newcustomer;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustomerSteps {

	WebDriver driver;
	String firstName = "Balaji";
	String lastName = "Shan";
	String email = "balajidf1435@gmail.com";
	
	@Test
	public void newCustomer() throws Exception {

		System.setProperty("WebDriver.Chrome.driver",
				"./driver/chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("http://automationpractice.com");
		driver.manage().window().maximize();

		// Sign In
		WebElement signIn = driver.findElement(By.className("login"));
		signIn.click();

		// Enter Email Address
		WebElement enterEmail = driver.findElement(By.name("email_create"));
		enterEmail.sendKeys(email);

		// Create Account
		WebElement createAcc = driver.findElement(By.name("SubmitCreate"));
		createAcc.submit();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		// Fill form
		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();
		driver.findElement(By.xpath("//input[@id='customer_firstname']"))
				.sendKeys(firstName);
		driver.findElement(By.xpath("//input[@id='customer_lastname']"))
				.sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys(
				"India@01");
		driver.findElement(By.xpath("//input[@id='address1']")).sendKeys(
				"Address adress");
		driver.findElement(By.xpath("//input[@id='city']")).sendKeys("Chennai");

		Select selectState = new Select(driver.findElement(By
				.xpath("//select[@id='id_state']")));
		selectState.selectByIndex(2);

		driver.findElement(By.xpath("//input[@id='postcode']")).sendKeys(
				"62560");

		Select selectCountry = new Select(driver.findElement(By
				.name("id_country")));
		selectCountry.selectByVisibleText("United States");

		driver.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys(
				"9566902215");
		driver.findElement(By.xpath("//input[@name='alias']")).sendKeys(
				"vm promters");

		// Submit Form

		driver.findElement(By.xpath("//button[@id='submitAccount']")).click();
		Thread.sleep(5000);

		// Assert 
		
		Assert.assertTrue("USER NAME INCORRECT", driver.findElement(By.linkText((firstName + " " + lastName))) != null);
		
		Assert.assertTrue("WISHLIST NOT PRESENT", driver.findElement(By.linkText("MY WISHLISTS")) != null);
		
		driver.findElement(By.xpath("//a[@title='My wishlists']")).click();
		
		Assert.assertTrue("TOP SELLER NOT PRESENT", driver.findElement(By.linkText("TOP SELLERS")) != null);
		
		driver.findElement(By.xpath("//img[@src='http://automationpractice.com/img/p/2/0/20-small_default.jpg']")).click();
		
		// Add to Cart
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@id='wishlist_button']")).click();
		
		
		driver.navigate().to("http://automationpractice.com/index.php?fc=module&module=blockwishlist&controller=mywishlist");
		
		Assert.assertTrue("TOP SELLER NOT PRESENT", driver.findElement(By.linkText("My wishlist")) != null);

		driver.quit();
	}

}
