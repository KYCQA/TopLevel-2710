package Testcases;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class NewRegistration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.getProperty("webdriver.chrome.driver", "./chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();
		driver.get("http://automationpractice.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


		driver.findElementByXPath("//a[@class='login']").click();
		// login link
		//enter emaid id
		driver.findElementByXPath("//input[@id='email_create']").sendKeys("Latcham6.a@rediffmail.com");

		//click on the Create button
		driver.findElementByXPath("//button[@class = 'btn btn-default button button-medium exclusive'] ").click();

		//select title
		driver.findElementByXPath("//input[@id='id_gender1']").click();

		//type first name

		driver.findElementByXPath("//input[@id='customer_firstname']").sendKeys("Customer Latcham");
		//type last name


		//input[@id='customer_lastname']
		driver.findElementByXPath("//input[@id='customer_lastname']").sendKeys("Custer latcham");

		//select days
//type password
		driver.findElementByXPath("//input[@name='passwd']").sendKeys("password");
		//Select[@id='days']
		WebElement days = driver.findElementByXPath("//Select[@id='days']");
		selectByvalue( days,  "15");

		//Select[@id='months']
		WebElement mon = driver.findElementByXPath("//Select[@id='months']");
		selectByvalue( mon,  "5");
		//Select[@id='years']
		WebElement year = driver.findElementByXPath("//Select[@id='years']");
		selectByvalue( year,  "1977");
		//Select[@id='newsletter']
		driver.findElementByXPath("//input[@id='optin']").click();
		//input[@id='optin']


		driver.findElementByXPath("//input[@id='optin']").click();
		//input[@id='firstname']
		driver.findElementByXPath("//input[@id='firstname']").sendKeys("add latcham");
		//input[@id='lastname']
		driver.findElementByXPath("//input[@id='lastname']").sendKeys("add latcham");
		driver.findElementByXPath("//input[@id='company']").sendKeys("companyName");
		driver.findElementByXPath("//input[@id='address1']").sendKeys("companyaddress1");
		driver.findElementByXPath("//input[@id='address2']").sendKeys("companyaddress2");
		driver.findElementByXPath("//input[@id='city']").sendKeys("city name");
		WebElement state = driver.findElementByXPath("//Select[@id='id_state']");
		selectByvisibleText( state,  "Delaware");
		driver.findElementByXPath("//input[@id='postcode']").sendKeys("62341");
		WebElement country = driver.findElementByXPath("//Select[@id='id_country']");
		selectByvisibleText( country,  "United States");
		driver.findElementByXPath("//textarea[@id='other']").sendKeys("entered by latcham during interview");
		driver.findElementByXPath("//input[@id='phone']").sendKeys("24352345");
		driver.findElementByXPath("//input[@id='phone_mobile']").sendKeys("9094020939");
		driver.findElementByXPath("//input[@id='alias']").sendKeys("addalias");
		driver.findElementByXPath("//button[@id='submitAccount']").click();
		String customerNameinLoggedinPage = driver.findElementByXPath("//a[@class='account']").getText();
		//customername verification
		if (customerNameinLoggedinPage.contains("la"))
				System.out.println("Customer Verificaiton competed and TC passed");
		else
			System.out.println("Customer Verificaiton competed and TC failed since name does not match");
		 String Mywisheslist = driver.findElementByXPath("//a[@title='My wishlists']").getText();
		
		//mywished list verificaiotn
		if (Mywisheslist.contains("wishlists"))
				System.out.println("Mywisheslist Verificaiton competed and TC passed");
		else
			System.out.println("Mywisheslist Verificaiton competed and TC failed since Mywisheslist does not match");
		driver.findElementByXPath("//a[@title='My wishlists']").click(); 
				
		
		//top sellert verificaiotn
		String topseller = driver.findElementByXPath("//a[@title='View a top sellers products']").getText();
		if (topseller.contains("Top"))
				System.out.println("top sellert Verificaiton competed and TC passed");
		else
			System.out.println("top sellert Verificaiton competed and TC failed since top sellert does not match");
		
		
		//click on the first product in the top seller list
		
driver.findElementByXPath("(//img[@class='replace-2x img-responsive'])[1]").click();
String itemdesc = driver.findElementByXPath("//p[text()='Printed chiffon knee length dress with tank straps. Deep v-neckline.']").getText();
System.out.println(itemdesc);
driver.findElementByXPath("//a[@id='wishlist_button']").click();
driver.findElementByXPath("//a[@class='fancybox-item fancybox-close']").click();

driver.findElementByXPath("//span[text()='Customer Latcham Custer latcham']").click();
driver.findElementByXPath("//span[text()='My wishlists']").click();
List<WebElement> productlist = driver.findElementsByXPath("//a[@class='product-name']");
for (WebElement each : productlist) {
	String text = each.getText();
	System.out.println(text);
	if (text.contains("Printed"))
		System.out.println("selected production is avilalbe in wished list");
	else
		System.out.println("selected production is not avilalbe in wished list");



}

	
	}

	public static void selectByvalue(WebElement ele, String data)
	{
		Select statesel = new Select(ele);
		statesel.selectByValue(data);
	}


	
	public static void selectByvisibleText(WebElement ele, String data)
	{
		Select statesel = new Select(ele);
		statesel.selectByVisibleText(data);
	}

}